# src/limit_orders.py

import sys
from binance.enums import *
from basic_bot import BasicBot

try:
    symbol = sys.argv[1]
    side = sys.argv[2].upper()
    quantity = float(sys.argv[3])
    price = float(sys.argv[4])
except IndexError:
    print(" Usage: python limit_orders.py BTCUSDT BUY 0.01 60000")
    sys.exit(1)

bot = BasicBot()
print(" Connected to Binance Testnet!")

try:
    order = bot.client.futures_create_order(
        symbol=symbol,
        side=SIDE_BUY if side == "BUY" else SIDE_SELL,
        type=ORDER_TYPE_LIMIT,
        timeInForce=TIME_IN_FORCE_GTC,
        quantity=quantity,
        price=price
    )

    print(" Limit Order Placed Successfully!")
    print(order)

except Exception as e:
    print(" Error placing limit order:", str(e))
