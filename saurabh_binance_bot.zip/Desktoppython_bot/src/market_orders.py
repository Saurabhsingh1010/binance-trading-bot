# src/market_orders.py

import sys
from binance.enums import *
from basic_bot import BasicBot

try:
    symbol = sys.argv[1]         # e.g., BTCUSDT
    side = sys.argv[2].upper()   # BUY or SELL
    quantity = float(sys.argv[3])
except IndexError:
    print(" Error: Please provide arguments like: BTCUSDT BUY 0.01")
    sys.exit(1)

try:
    bot = BasicBot()
    print(" Connected to Binance Testnet!")

    order = bot.client.futures_create_order(
        symbol=symbol,
        side=SIDE_BUY if side == "BUY" else SIDE_SELL,
        type=ORDER_TYPE_MARKET,
        quantity=quantity
    )

    print(" Market Order Placed Successfully!")
    print(order)

except Exception as e:
    print(" Error placing order:", str(e))
