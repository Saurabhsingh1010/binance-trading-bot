from binance.client import Client
from dotenv import load_dotenv
import os
import logging
import time
import requests

class BasicBot:
    def __init__(self, testnet=True):
        load_dotenv()
        api_key = os.getenv("API_KEY")
        api_secret = os.getenv("API_SECRET")

        # Create Binance client
        self.client = Client(api_key, api_secret)
        
        # Set Testnet URL
        if testnet:
            self.client.API_URL = 'https://testnet.binancefuture.com'
            self.client.FUTURES_URL = 'https://testnet.binancefuture.com/fapi'

        server_time = requests.get("https://testnet.binancefuture.com/fapi/v1/time").json()["serverTime"]
        local_time = int(time.time() * 1000)
        self.client.timestamp_offset = server_time - local_time

        # Logging
        logging.basicConfig(filename='bot.log', level=logging.INFO,
                            format='%(asctime)s - %(levelname)s - %(message)s')
