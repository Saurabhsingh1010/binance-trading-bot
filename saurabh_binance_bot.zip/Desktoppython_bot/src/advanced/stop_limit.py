import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from basic_bot import BasicBot

try:
    symbol = sys.argv[1]
    side = sys.argv[2].upper()
    quantity = float(sys.argv[3])
    stop_price = float(sys.argv[4])
except IndexError:
    print(" Usage: python stop_limit.py BTCUSDT BUY 0.01 61000")
    sys.exit(1)

bot = BasicBot()
print(" Connected to Binance Testnet!")

try:
    order = bot.client.futures_create_order(
        symbol=symbol,
        side="BUY" if side == "BUY" else "SELL",
        type="STOP_MARKET",          
        quantity=quantity,
        stopPrice=stop_price,
        timeInForce="GTC"
    )

    print("Stop-Market Order Placed Successfully!")
    print(order)

except Exception as e:
    print("Error placing stop-market order:", str(e))
